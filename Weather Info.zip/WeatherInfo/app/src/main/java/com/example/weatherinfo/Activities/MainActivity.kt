package com.example.weatherinfo.Activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherinfo.Adapters.WeatherAdapter
import com.example.weatherinfo.Models.WeatherData
import com.example.weatherinfo.R
import com.example.weatherinfo.WeatherNetworkingAPI.WeatherAPI
import java.io.Serializable


class MainActivity : AppCompatActivity() {

    private lateinit var weatherAdapter: WeatherAdapter
    private var weatherDataSource: MutableList<WeatherData> = mutableListOf()
    private var recyclerView: RecyclerView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.weather_data_activity)
        WeatherAPI().getWeatherData {
            if (!it.isEmpty()) {
                weatherDataSource.addAll(it)

                runOnUiThread {
                    setupRecyclerView()
                }
            }
        }
    }

    private fun setupRecyclerView() {

        recyclerView = findViewById(R.id.recyclerView)

        weatherAdapter = WeatherAdapter(this, weatherDataSource) { weatherDataDay ->
            val weatherIntent = Intent(this, WeatherDetailActivity::class.java).apply {
                putExtra(WEATHERDAY, weatherDataDay)
            }
            startActivity(weatherIntent)
        }

        recyclerView?.layoutManager = LinearLayoutManager(this)
        recyclerView?.layoutManager = LinearLayoutManager(
            this,
            LinearLayoutManager.VERTICAL,
            false
        )
        recyclerView?.adapter = weatherAdapter
    }
}
const val WEATHERDAY = "com.example.weatherinfo.MESSAGE"