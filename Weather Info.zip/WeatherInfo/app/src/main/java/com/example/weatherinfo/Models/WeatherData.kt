package com.example.weatherinfo.Models

import java.io.Serializable

class WeatherData (
    date: String = "",
    tempMax: Double,
    tempMin: Double,
    rainTotalMm: Double): Serializable {
    var dayDescription: String = ""
    var icon: String = ""
    var date: String = ""
    var tempMax: Double = 0.0
    var tempMin: Double = 0.0

    init {
        this.date = date
        this.tempMax = tempMax
        this.tempMin = tempMin
        if (rainTotalMm == 0.0) {
            dayDescription = "Weather is fine today you should not be worried at all."
            icon = "clear"
        } else if (rainTotalMm > 0.0 && rainTotalMm < 10.0) {
            dayDescription = "Weather is fine today but you should consider rainy periods of the day, take caution."
            icon = "cloudy"
        } else {
            dayDescription = "Weather is bad today you should be worried about allergy."
            icon = "rain"
        }
    }
}