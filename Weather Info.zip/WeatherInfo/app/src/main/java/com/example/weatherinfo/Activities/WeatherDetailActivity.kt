package com.example.weatherinfo.Activities

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.example.weatherinfo.Models.WeatherData
import com.example.weatherinfo.R

class WeatherDetailActivity : AppCompatActivity() {
    var weatherDay: WeatherData? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weather_detail)

        weatherDay = intent.getSerializableExtra(WEATHERDAY) as WeatherData
        setWeatherData(weatherDay!!)
    }

    @SuppressLint("SetTextI18n")
    private fun setWeatherData(weatherData: WeatherData) {
        val textView = findViewById<TextView>(R.id.weatherDetaildDescription)
        textView.text = weatherData.dayDescription
        val tempMinMax = findViewById<TextView>(R.id.tempMinMax)
        tempMinMax.text = "Minimum temperature: " + weatherData.tempMin.toString() + "C" + "\r" + "Maximum temperature: " + weatherData.tempMax + "C"

        findViewById<ImageView>(R.id.weatherIcon).apply {
            val resID = context.resources.getIdentifier(
                weatherData.icon,
                "drawable",
                context.packageName
            )
            setImageResource(resID)
        }
    }
}