package com.example.weatherinfo.WeatherNetworkingAPI

import com.example.weatherinfo.Models.WeatherData
import com.google.android.gms.maps.model.LatLng
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL


class WeatherAPI {
    private val appId: String = "a45eba4a"
    private val apiKey: String = "d52fb350cafea58cddd21a8a286d70e3"
    private val apiURL: String = "http://api.weatherunlocked.com/api/forecast"
    private val belgradeCoordinates = LatLng(44.816307, 20.460418)

    fun getWeatherData(callback: (weatherData: MutableList<WeatherData>) -> Unit) {
        val thread = Thread {
            try {
                val urlString = "$apiURL/${belgradeCoordinates.latitude},${belgradeCoordinates.longitude}?app_id=$appId&app_key=$apiKey"
                val url = URL(urlString)
                val weatherDataArray: MutableList<WeatherData> = mutableListOf()
                with(url.openConnection() as HttpURLConnection) {
                    requestMethod = "GET"
                    inputStream.bufferedReader().use {
                        it.lines().forEach { line ->
                            val weatherObject = JSONObject(line)
                            val daysArray = weatherObject.getJSONArray("Days")
                            for (i in 0 until daysArray.length()-1) {
                                val item = daysArray.getJSONObject(i)
                                val date = item.getString("date")
                                val tempMax = item.getDouble("temp_max_c")
                                val tempMin = item.getDouble("temp_min_c")
                                val rainTotalMm = item.getDouble("rain_total_mm")

                                val weatherDataDay = WeatherData(
                                    date,
                                    tempMax,
                                    tempMin,
                                    rainTotalMm
                                )
                                weatherDataArray.add(weatherDataDay)
                            }
                        }
                        callback(weatherDataArray)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        thread.start()
    }
}