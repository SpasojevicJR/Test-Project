package com.example.weatherinfo.Adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherinfo.Models.WeatherData
import com.example.weatherinfo.R

class WeatherAdapter(val context: Context, val weatherDataSource: MutableList<WeatherData>, val itemClick: (WeatherData) -> Unit) : RecyclerView.Adapter<WeatherAdapter.Holder>() {

    inner class Holder(itemView: View, val itemClick: (WeatherData) -> Unit) : RecyclerView.ViewHolder(itemView) {
        val dayDescription = itemView.findViewById<TextView>(R.id.weatherDescription)
        val date = itemView.findViewById<TextView>(R.id.weatherDate)
        val icon = itemView.findViewById<ImageView>(R.id.weatherIconView)

        fun bindWeather(weatherDataSource: WeatherData) {
            val resID = context.resources.getIdentifier(
                weatherDataSource.icon,
                "drawable",
                context.packageName
            )
            dayDescription?.text = weatherDataSource.dayDescription
            date?.text = weatherDataSource.date
            icon?.setImageResource(resID)

            itemView.setOnClickListener { itemClick(weatherDataSource) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(context).inflate(R.layout.main_activity_weatherdata_recyclerview_cells, parent, false)
        return Holder(view, itemClick)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.bindWeather(weatherDataSource[position])
    }

    override fun getItemCount(): Int {
        return weatherDataSource.count()
    }
}